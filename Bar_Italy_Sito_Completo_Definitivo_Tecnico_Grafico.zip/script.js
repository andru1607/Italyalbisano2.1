function acceptCookies() {
  document.getElementById('cookie-banner').style.display = 'none';
}
